import React from "react";

// import "../css/Workers.css";

// Functional component
const Workers = () => {
  return <div id="">
    Workers
  </div>;
};

export default Workers;
