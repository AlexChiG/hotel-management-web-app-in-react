import React from "react";

// import "../css/Rooms.css";

// Functional component
const Rooms = () => {
  return <div id="">
    Rooms
  </div>;
};

export default Rooms;
