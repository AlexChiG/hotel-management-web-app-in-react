import React from "react";

// import "../css/Reservations.css";

// Functional component
const Reservations = () => {
  return <div id="">
    Reservations
  </div>;
};

export default Reservations;
