import React from "react";

// import "../css/Clients.css";

// Functional component
const Clients = () => {
  return <div id="">
    Clients
  </div>;
};

export default Clients;
