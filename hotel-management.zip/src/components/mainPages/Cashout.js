import React from "react";

// import "../css/Cashout.css";

// Functional component
const Cashout = () => {
  return <div id="">
    Cashout
  </div>;
};

export default Cashout;
