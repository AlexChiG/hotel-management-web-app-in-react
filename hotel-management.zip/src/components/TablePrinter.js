import React, { useEffect, useState } from 'react'

import "../css/tablePrinter.css"

// Functional component
const TablePrinter = () => {

    const [data, setData] = useState([])
    useEffect(()=> {
      fetch('http://localhost:8081/test')
      .then(res => res.json())
      .then(data => setData(data))
      .catch(err => console.log(err))
    }, [])

    return (
        <table>
          <thead>
            <th>ID</th>
            <th>Nume</th>
          </thead>
          <tbody>
            {data.map((d, i) => (
              <tr key={i}>
                <td>{d.id}</td>
                <td>{d.nume}</td>
              </tr>
            ))}
          </tbody>
        </table>
      );
    };
    
    export default TablePrinter;
    